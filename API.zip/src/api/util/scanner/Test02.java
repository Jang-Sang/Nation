package api.util.scanner;

import java.awt.event.ActionEvent;
import java.util.Scanner;

public class Test02 {

	public static void main(String[] args) {
		
		String text = "빨-주-노-초/파-남-보";
		
		Scanner sc = new Scanner(text);
		
		//구별자를 통해서 데이터를 읽어올수도 있다...
		//sc.useDelimiter("-");
//		sc.useDelimiter("/");
		
		sc.useDelimiter("[-/]");
		
		while(sc.hasNext()) {
			System.out.println(sc.next());
		}
		
		sc.close();
		
		
	}
	
}
