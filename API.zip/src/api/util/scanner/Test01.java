package api.util.scanner;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.Scanner;

public class Test01 {

	public static void main(String[] args) {
		
		//Iterator<E> - 반복자 - 1.2버전
		//Enumeration<E> - 1.0버전 
		
		String song = "첫눈 내릴 어느 날엔\r\n" + 
				"널 안고 있을까\r\n" + 
				"하얀 배경이 너의 맘에\r\n" + 
				"날 데려가 줄까\r\n" + 
				"온 세상이 너로 뒤덮이면\r\n" + 
				"내 세상은 너의 것이 되고";
		
		Scanner sc = new Scanner(song);
		
		while(sc.hasNext()) {
			System.out.println(sc.hasNext());
			System.out.println(sc.next());			
		}
		
		sc.close();
		
		System.out.println(sc);
		
		System.out.println("==============================");
		
		sc = new Scanner("1 2 3 4 5");

		if(sc.hasNextInt()) {
			System.out.println(sc.nextInt());
		}
		
//		while(sc.hasNextLine()) {
//			System.out.println(sc.hasNextLine());
//			System.out.println(sc.nextLine());			
//		}
		
	}
}














