package api.util.scanner;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Test03 {

	public static void main(String[] args) {
		
		Scanner sc = null;
		
		//파일
		File target = new File("API.txt");

		try {
			sc = new Scanner(target);
			
			while(sc.hasNextLine()) {
				System.out.println(sc.nextLine());
			}
			
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}finally {
			if(sc!= null) {
				sc.close();
			}
		}
		
		
	}

}
