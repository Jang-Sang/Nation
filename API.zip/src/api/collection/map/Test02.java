package api.collection.map;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

public class Test02 {
//	[도서 등록 프로그램 구현]
//	사용자에게 계속해서 도서명을 입력받아 저장하는 저장소를 구현하려고 합니다
//	이미 등록된 책이면 등록이 거절되었으면 합니다
//	(예상 결과)	도서명 : 어린 왕자
//			도서 등록이 되었습니다... 현재 도서 1개
//			도서명 : 키다리 아저씨
//			도서 등록이 되었습니다... 현재 도서 2개
//			도서명 : 어린 왕자
//			이미 등록된 도서입니다.
//			도서명 : 종료
//			프로그램을 종료합니다.
	
	public static void main(String[] args) {
		
		Map<String, Integer> map = new HashMap<String, Integer>();
		
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			if(map.isEmpty()) {
				System.out.println("데이터가 없습니다.");
			}else {
				for(Entry<String, Integer> en : map.entrySet()) {
					System.out.println(en.getKey() + " : " + en.getValue() + "원");
				}
			}
			
			System.out.print("도서명 : ");
			String name = sc.next();
			System.out.print("가격 입력 : ");
			int price = sc.nextInt();
			
			if(map.containsKey(name)) {
//				map.replace(name, price);
				System.out.println(name + "의 가격이 " + price + "원으로 수정되었습니다.");
			}else {
				System.out.println(name + "가 " + price + "원으로 설정되었습니다.");
			}
			map.put(name,price);
			
		}
		
	}
	
}




































