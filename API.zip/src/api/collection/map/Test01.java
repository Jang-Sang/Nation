package api.collection.map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Test01 {

	public static void main(String[] args) {
		
//		Map<String, Object> map = new HashMap<String, Object>();
//		
//		map.put("name", "김민준");
//		
////		Object name = map.get("name");
//		String name = (String)map.get("name");
//		
//		System.out.println(name.charAt(0));
		
		
		Map<String, Integer> map = new HashMap<String, Integer>();
		
		System.out.println(map.put("a", 100));
		System.out.println(map.put("a", 50));
		map.put("b", 10);
		map.put("c", 102);
		map.put("d", 50);
		
		System.out.println(map.size());
		
		System.out.println(map.get("a"));
		
		System.out.println(map.containsKey("a"));
		System.out.println(map.containsKey(50));
		
		System.out.println(map.containsValue("a"));
		System.out.println(map.containsValue(50));
		
		//데이터 추출
//		Set<String> set = map.keySet();
//		
//		Iterator<String> it = set.iterator();
//		
//		while(it.hasNext()) {
//			String key = it.next();
//			int value = map.get(key);
//			System.out.println(key + " - " + value);
//		}
		
		System.out.println(map.remove("a"));
		
		
		for(Map.Entry<String, Integer> en : map.entrySet()) {
			String key = en.getKey();
			int value = en.getValue();
			System.out.println(key + " - " + value);
		}
		
	}
	
}


























