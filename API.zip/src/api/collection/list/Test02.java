package api.collection.list;

import java.util.ArrayList;

public class Test02 {

	public static void main(String[] args) {
		ArrayList<Menu> list = new ArrayList<Menu>();
		Menu m = new Menu("율무차", 250);
		list.add(new Menu("커피", 200));
		list.add(m);
		list.add(new Menu("코코아", 250));


		System.out.println(m);
		System.out.println(list.get(1));
		
		//System.out.println(list.contains());
		
		for(int i = 0; i < list.size(); i++) {
			list.get(i).disp(i + 1);
		}
		
		for(int i = 0; i < list.size(); i++) {
			m = list.get(i);
			if(m.getName().equals("커피")) {
				//list.remove(i);
				m.setPrice(20000);				
			}
		}
		
		for(int i = 0; i < list.size(); i++) {
			list.get(i).disp(i + 1);
		}
		
	}

}
