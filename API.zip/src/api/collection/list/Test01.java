package api.collection.list;

import java.util.ArrayList;

public class Test01 {

	public static void main(String[] args) {
		
		//Collections Framework - 무한의 데이터를 저장할수 있는 공간
		// - 최소한의 자원으로 최대한의 효율을 낼수 있도록 만든 프로그램의 기본 틀
		
		//ArrayList - 확장형 배열...
	
		ArrayList<String> list = new ArrayList<String>();
		
		//데이터 추가 - .add(e) - 자동으로 제일 마지막에 데이터를 추가한다...
		list.add("수박");		//0
		list.add("망고스틴");	//1 -> 2
		list.add("감");			//2 -> 3
		list.add("용과");		//3 -> 4
		list.add("체리");		//4 -> 5
		list.add("샤인머스켓");	//5 -> 6
//		list.add(12.34);
//		list.add(1);
//		list.add('c');
		
		list.add(1,"무화과"); //1
		
		// 데이터 개수 - .size();
		System.out.println(list.size());
		
		//데이터 추출 - .get(i)
		
		System.out.println(list.get(1));
	
		for(int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}
		
		// indexOf(E) - 데이터 검색 데이터가 있으면 인덱스값 반환 없으면 -1 반환
		
		System.out.println(list.indexOf("수박"));
		System.out.println(list.indexOf("소주"));
		
		System.out.println("==============================================");
		
		// 데이터 삭제 - .remove()
		System.out.println(list.remove(0));
		System.out.println(list.remove("무화과1"));
		
		
		for(int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}
		
		System.out.println("-=================================");
		//데이터 검색 - 데이터가 있으면 true 없으면 false
		System.out.println(list.contains("수박"));
		System.out.println(list.contains("무화과"));
		
		// isEmpty() - 데이터가 있냐 없냐
		System.out.println(list.isEmpty());
		
		list.clear(); // 데이터 비우기
		
		System.out.println(list.isEmpty());
	}
	
}


























