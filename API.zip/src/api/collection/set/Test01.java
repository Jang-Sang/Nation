package api.collection.set;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Test01 {

	public static void main(String[] args) {
		
		Set<String> set = new HashSet<String>();
		
		//데이터 추가
		set.add("딸기");
		set.add("망고스틴");
		set.add("감");
		set.add("블루베리");
		System.out.println(set.add("체리"));
		System.out.println(set.add("체리"));
		
		System.out.println(set.size());
	
		//데이터 추출.... getX
		
//		for(String s : set) {
//			System.out.println(s);
//		}
		
		//iterator() - 순서가 있는 형태의 객체를 반환하는 메소드
		Iterator<String> it = set.iterator();

//		set.remove("감");
		
		while(it.hasNext()) {
			String s = it.next();
			if(s.equals("감")) {
				it.remove();
			}
			System.out.println(s);
		}
		
//		it = set.iterator();
//		
//		while(it.hasNext()) {
//			System.out.println(it.next());
//		}
		

		System.out.println(set.contains("체리"));
		
		System.out.println(set.toString());
	
	}

}




























