package api.lang.math;

public class Test01 {

	
	public static void main(String[] args) {
		
		//Math - 수학계산 클래스...
		
		double a = 1.5;
		
		System.out.println(Math.floor(a)); //버림
		System.out.println(Math.round(a)); //반올림
		System.out.println(Math.ceil(a));  //올림
		
		
		int b = 3;
		int c = 4;
		
		System.out.println(Math.pow(b, 3));
		System.out.println(Math.pow(c, 2));
		
		
		double d = Math.pow(b, 2) + Math.pow(c, 2);
		
		double e = Math.sqrt(d);
		System.out.println(e);
	}
	
}
