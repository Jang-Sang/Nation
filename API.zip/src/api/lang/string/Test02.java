package api.lang.string;

public class Test02 {

	public static void main(String[] args) {
		
		
		String a = "Hello";
		String b = new String("Hello");
		char[] arr = new char[] {'h','e','l','l','o'};
		String c = new String(arr);
		
		System.out.println(a.equals(b));
		
		System.out.println(a.getClass());
		
		System.out.println(a.equals(c));
		
		System.out.println(a.toLowerCase()); // 소문자 변환
		System.out.println(a.toUpperCase()); // 대문자 변환
		
		System.out.println(a.toLowerCase().equals(c));
		
		System.out.println(a.equalsIgnoreCase(c)); // 대소문자 무시한 비교...
		
		
		//문자열 검색
		String email = "darkrose777@naver.com";
		
		System.out.println(email.contains("co"));//문자열을 포함하고 있으면 true 아니면 false
		System.out.println(email.indexOf("com1")); // 포함하면 인덱스값 아니면 -1
		System.out.println(email.startsWith("na"));// 문자열로 시작하면 true 아니면 false
		System.out.println(email.endsWith("com")); // 이 문자열로 끝나느냐?
		
		System.out.println(email.indexOf('r',10));
		
		System.out.println(email.lastIndexOf('r'));
		System.out.println(email.lastIndexOf('r',10));
		
		//문자 추출
		System.out.println(email.charAt(2));
		
	}
	
}





























