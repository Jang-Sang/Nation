package api.lang.string;

public class Test03 {

	public static void main(String[] args) {
		
		
		//문자열 편집
		String email = "darkrose777@naver.com";
		
		//문자열 자르기
		System.out.println(email.substring(3)); //3번 인덱스 부터
		System.out.println(email.substring(3,5)); // 3번 부터 5번 이전 인덱스
		
	
		//문자열 치환
		String song = "가라 잘가라 가라 멀리 가버려";
		
		System.out.println(song.replace("가라", "와라"));
		
		//문자열 공백 제거
		email = "         darkrose777@naver.com           ";
		System.out.println(email);
		System.out.println(email.length());
		System.out.println(email.trim());
		System.out.println(email.trim().length());
	}
	
}
