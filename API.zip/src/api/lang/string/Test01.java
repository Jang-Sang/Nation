package api.lang.string;

import java.util.Scanner;

public class Test01 {

	public static void main(String[] args) {
//		java.lang.String 메소드 이용해서 
//		쿵쿵따 게임
//		(규칙)	
//			[1] 사용자에게 계속해서 단어를 입력받습니다
//			[2] 입력된 단어가 3글자가 아니면 게임을 종료합니다 - 	length()
//			[3] 이전 입력된 단어의 마지막 글자와 - charAt(int index)
//			     지금 입력한 단어의 첫 글자가 같을 때만 진행, 아니면 종료합니다
//			(예) 	바나나 → 나비 (2글자라서 종료)
//				고무공 → 공놀이 → 이니셜 → 설리반 (끝/처음 불일치로 종료)		
		
		Scanner sc = new Scanner(System.in);
		String prev = null;
		String next = null;
		while(true) {
			prev = next;
			System.out.print("단어 입력 : ");
			next = sc.next();
			
			if(next.length() != 3) {
				System.out.println("3글자만 입력하셔야 합니다.");
				break;
			}
			
			if(prev == null) {
				System.out.println("첫단어 입력입니다.");
			}else {
				if(next.charAt(0) == prev.charAt(2)) {
					System.out.println(prev + " -> " + next);
					System.out.println("계속진행하십시오..");
				}else {
					System.out.println("불일치 입니다!");
					break;
				}
			}
		}
		
		sc.close();
		
	}
	
}




















