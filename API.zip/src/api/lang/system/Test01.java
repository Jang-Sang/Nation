package api.lang.system;

public class Test01 {

	public static void main(String[] args) {
		
		// System 클래스 - 운영체제와 관련한 정보를 가진 클래스
		
		Test01 t = new Test01();
		
		System.out.println(t);
		System.err.println(t.getClass().getName()+ "@" + Integer.toHexString(t.hashCode()));

		//시스템 정보 불러오기...
		System.out.println(System.getProperty("os.name"));
		System.out.println(System.getProperty("java.runtime.version"));
		System.out.println(System.getProperty("user.home"));
		
	}
	
}
