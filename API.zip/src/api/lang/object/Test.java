package api.lang.object;

public class Test {

	int a = 5;
	
	//오버라이드...메소드의 재정의
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return a;
	}
	
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return this.hashCode() == obj.hashCode();
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "a = " + a;
	}
	
	
	public static void main(String[] args) {
		
		//Object - JAVA의 모든 클래스의 조상
		// - 클래스를 만들면 자동으로 상속받는 클래스...
		// - 모든 클래스에서 공통적으로 사용되는 기능들을 정의한 클래스

		Object a = new Object();
		Object b = new Object();
		
		Test c = new Test();
		Object d = new Test();
		
		//getClass() - 실제 인스턴스 공간의 타입을 알려주는 메소드
		System.out.println(a.getClass());
		System.out.println(c.getClass());
		System.out.println(d.getClass());
		
		//hashCode() - 인스턴스 공간의 일련번호
		System.out.println(a.hashCode());
		System.out.println(b.hashCode());
	
		//.equals(obj) - 객체끼리의 동일 비교....
		System.out.println(c == d);
		System.out.println(c.equals(d));
		
		
		String s1 = "김민준"; // new String("김민준"); // autoboxing
		String s2 = new String("김민준");
		
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
	
		System.out.println(s1 == s2); // false
		System.out.println(s1.equals(s2));

		//.toString() - 객체 정보를 정리해서 문자열로 반환하는 메소드
		System.out.println(a);
		System.out.println(a.toString());
		
		System.out.println(c);
		System.out.println(c.toString());
	}

}
























