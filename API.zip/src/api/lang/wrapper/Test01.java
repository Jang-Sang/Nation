package api.lang.wrapper;

public class Test01 {

	public static void main(String[] args) {
		//wrapper 클래스
		// - 기본형 자료형을 참조형으로 만들어 놓은 클래스
		Boolean a = new Boolean(true);//false
		Boolean b = new Boolean("TrUe");
		
		System.out.println(a);
		System.out.println(b);
		
		System.out.println(a.hashCode());
		
		System.out.println(a == b);
		System.out.println(a.equals(b)); // 객체 동일 비교
		
		a = Boolean.valueOf(b);
		
		System.out.println(a);
		
		boolean c = Boolean.parseBoolean("TURE");
		
		System.out.println(c);
		
		//자동변환
		
		//Auto-Boxing - 기본형 -> 참조형
		Boolean d = true;
		//Auto-UnBoxing - 참조형 -> 기본형
		boolean e = new Boolean("false");
	}

}
























