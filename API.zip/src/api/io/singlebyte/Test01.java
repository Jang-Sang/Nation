package api.io.singlebyte;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class Test01 {

	public static void main(String[] args) {
		
		//파일 입출력
		// - 파일 열기 - 입력
		// - 파일 저장 - 출력

		// 파일 저장.
		
		File target = new File("files");
		
		try {
			if(!target.exists()) {
				target.mkdirs();
			}
			target = new File(target, "single.txt");
			if(!target.exists()) {
				target.createNewFile();
			}
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		OutputStream out = null;
		//target에 대한 출력...
		try {
			/*OutputStream */out = new FileOutputStream(target);
			// CPU -> out -> target -> 실제파일
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		try {
			out.write(65);
			out.write(66);
			out.write(97);
			out.write('b');
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		//닫기
		try {
			out.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
}


















