package api.io.singlebyte;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class Test03 {

	public static void main(String[] args) {
		
		File target = new File("files","single.txt");
		
		InputStream in = null;
		
		try {
			in = new FileInputStream(target);
			// 실제 파일 -> target -> inputStream -> CPU
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		
		//.read() - 1byte 단위로 읽어오는 메소드
		
		
		
		while(true) {
			try {
				int n = in.read();
				
				System.out.println((char)n);
				
				if(n == -1) {
					break;
				}
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		try {
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}
	
}

















