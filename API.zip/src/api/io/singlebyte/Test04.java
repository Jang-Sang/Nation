package api.io.singlebyte;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class Test04 {

	// 파일 복사...
	public static void main(String[] args) throws IOException {
		File a = new File("files", "oracle1.zip");		//불러올 파일
		File b = new File("files", "oracle2.zip");		//저장할 파일
		
		InputStream in = new FileInputStream(a);//입력 통로
		OutputStream out = new FileOutputStream(b);//출력 통로
		
		//[single.txt] → a → in → CPU → out → b → [target.txt]	
		
		while(true){
			int n = in.read();
			if(n == -1) break;
			out.write(n);
		}
		
		in.close();
		out.close();
		System.out.println("처리 완료");
	}
	
}
