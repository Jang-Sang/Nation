package api.io.singlebyte;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class Test02 {

	public static void main(String[] args) {

		OutputStream out = null;
		
		try {
			File target = new File("files");
			
			if (!target.exists()) {
				target.mkdirs();
			}
			target = new File(target, "single.txt");
			if (!target.exists()) {
				target.createNewFile();
			}
			
			out = new FileOutputStream(target);
			
			out.write(65);
			out.write(66);
			out.write(97);
			out.write('b');
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(out != null) {
					out.close();
				}
			}catch(IOException e) {
				e.printStackTrace();
			}
		}
		
		
	}

}
