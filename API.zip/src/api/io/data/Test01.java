package api.io.data;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Test01 {

	public static void main(String[] args) {
		
		/*
		 * 파일에 출력되어야 하는 형태는 1byte단위의 수치이다...
		 * 원하는 데이터타입으로 출력하기가 힘들다...
		 */
		
		FileOutputStream fos = null;
		DataOutputStream dos = null;
		
		try {
			fos = new FileOutputStream("output.txt");
			
			dos = new DataOutputStream(fos);
			
			dos.writeBoolean(true);
			dos.writeInt(2147483647);
			dos.writeInt(65);
			dos.writeDouble(123.456);
			//dos.writeChars("안녕하세요"); //문자열을 문자로 쪼개서 출력
			dos.writeUTF("안녕하세요");//문자열 출력
			
			
		}catch(IOException e) {
			e.printStackTrace();
		}finally {
			try {
				if(dos != null) dos.close();
				if(fos != null) fos.close();
			}catch(IOException e) {
				e.printStackTrace();
			}
		}
		
		
	}
	
}
