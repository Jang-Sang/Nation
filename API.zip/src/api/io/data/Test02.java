package api.io.data;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class Test02 {

	public static void main(String[] args) {
		
		DataInputStream dis = null;
		
		try {
			dis = new DataInputStream(new FileInputStream("output.txt"));
			System.out.println(dis.available()); // 파일에서 더 읽어 낼수 있는 양...
			boolean a = dis.readBoolean();
			System.out.println("a = " + a);
			System.out.println(dis.available());
			int b = dis.readInt();
			System.out.println("b = " + b);
			System.out.println(dis.available());
			int c = dis.readInt();
			System.out.println("c = " + c);
			double d = dis.readDouble();
			System.out.println("d = " + d);
//			String e = dis.readLine();
//			System.out.println(e);
			System.out.println(dis.available());
			String f = dis.readUTF();
			System.out.println(f);
			System.out.println(dis.available());
			f = dis.readUTF();//EOFException - 더이상 읽어올 데이터가 없을때 발생되는 예외...
			
			
		}catch(IOException e) {
			e.printStackTrace();
		}finally {
			try {
				if(dis != null) {
					dis.close();
				}
			}catch(IOException e) {
				e.printStackTrace();
			}
		}
		
		
	}
	
}

















