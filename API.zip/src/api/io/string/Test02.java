package api.io.string;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;

public class Test02 {

	public static void main(String[] args) throws IOException {
		
		
		//문자열 전용 통로를 이용하여 편하게 입/출력...
		File target = new File("files","string2.txt");
		
		Writer out = new FileWriter(target);
		PrintWriter printer = new PrintWriter(target);
		
		
		printer.append("JSP");
		
		//out.write("자바\n");

		
//		printer.println("자바");
//		printer.println("자바");
//		printer.println("자바");
//		printer.println("자바");
		
		out.close();
		printer.close();
		
	}
	
}
