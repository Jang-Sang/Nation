package api.io.string;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class Test01 {

	public static void main(String[] args) throws FileNotFoundException {
		
		//문자열 저장
		File target = new File("files","string1.txt");
		
		OutputStream out = new FileOutputStream(target);
		
		String text = "메일\r\n" + 
				"카페\r\n" + 
				"블로그\r\n" + 
				"지식iN\r\n" + 
				"쇼핑\r\n" + 
				"쇼핑LIVE\r\n" + 
				"Pay\r\n" + 
				"TV\r\n" + 
				"사전\r\n" + 
				"뉴스\r\n" + 
				"증권\r\n" + 
				"부동산\r\n" + 
				"지도\r\n" + 
				"VIBE\r\n" + 
				"도서\r\n" + 
				"웹툰";
		
		byte[] data = text.getBytes();
		try {
			out.write(data);
			
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
	}
	
}

























