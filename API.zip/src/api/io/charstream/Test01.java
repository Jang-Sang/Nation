package api.io.charstream;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Test01 {

	public static void main(String[] args) {
		BufferedWriter bw = null;
		try {
			
			bw = new BufferedWriter(new FileWriter("ouput.log"));
			
			bw.write("이제 마지막이다....");
			bw.newLine(); // 다음줄 이동....\n
			bw.write("아프다.....너무....엄마...");
			bw.flush();
			bw.newLine();
			bw.write("배도 고프네....");
			
			
		}catch(IOException e) {
			e.printStackTrace();
		}finally {
			try {
				if(bw != null) {
					bw.close();
				}
			}catch(IOException e) {
				e.printStackTrace();
			}
		}
		
		
	}
	
}
