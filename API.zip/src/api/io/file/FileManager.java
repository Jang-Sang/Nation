package api.io.file;

import java.io.File;

public class FileManager {

	public static void print(File f) {
		String res = null;
		
		if(f.isFile()) {
			res = String.format("%-20s%10s%20dbyte", f.getAbsolutePath(),"[파일]",f.length());
		}else if(f.isDirectory()) {
			res = String.format("%-20s%10s", "[" + f.getAbsolutePath() + "]","[폴더]");
		}
		
		System.out.println(res);
	}
	
	public static void printFolder(File folder) {
		if(!folder.isDirectory()) {
			System.out.println(String.format("%-20s%10s%20dbyte", folder.getName(),"[파일]",folder.length()));
		}else {
			File[] files = folder.listFiles();
			for(File file : files) {
				FileManager.print(file);
			}
		}
	}
	
	public static void printFolder2(File folder) {
		File[] files = folder.listFiles();
		for(File file : files) {
			if(file.isDirectory()) {
				printFolder2(file);
			}
			FileManager.print(file);
		}
	}
	
	public static void remove(File file) {
		if(file.isDirectory()) {
			File[] files = file.listFiles();
			for(File f : files) {
				remove(f);
			}
		}
		System.out.println(file + "삭제완료!");	
		file.delete();
	}
	
}





































