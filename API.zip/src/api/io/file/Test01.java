package api.io.file;

import java.io.File;
import java.io.IOException;

public class Test01 {

	public static void main(String[] args) {
		// java.io.File - 파일과 폴더를 구별하지 않고 함께 관리 하는 클래스....
		
		File f = new File(".","sample1.txt");
		
		System.out.println(f.exists()); // 대상이 존재하는가?
		System.out.println(f.isFile()); // 대상이 파일인가?
		System.out.println(f.isDirectory()); // 대상이 폴더인가?
		
		//파일 정보....
		System.out.println(f.getName()); // 파일명
		System.out.println(f.getParent()); // 경로
		System.out.println(f.getPath()); // 경로 + 파일명 (상대경로)
		System.out.println(f.getAbsolutePath()); // 경로 + 파일명 (절대 경로)
		System.out.println(f.length()); //파일 크기(byte)
		
		System.out.println(f.lastModified()); // 최종 수정 시각
		System.out.println(System.currentTimeMillis());
		
		System.out.println(f.canRead()); // 읽을수 있는가?
		System.out.println(f.canWrite()); // 쓸수 있는가?
	}

}
