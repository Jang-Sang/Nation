package api.io.file;

import java.io.File;
import java.io.IOException;

public class Test05 {

	public static void main(String[] args) {
		
		//파일 삭제
		File f = new File("sample2.txt");
		
		if(f.exists()) {
			System.out.println("있다.");
			System.out.println(f.delete());
			return;
		}else {
			try {
				System.out.println(f.createNewFile());
			}catch(IOException e) {
				e.printStackTrace();
			}
			
			try {
				Thread.sleep(5000);
			}catch(InterruptedException e) {
				e.printStackTrace();
			}
//			
//			System.out.println(f.delete());
		}
		
	}
	
}
