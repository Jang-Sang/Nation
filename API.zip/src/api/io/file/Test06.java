package api.io.file;

import java.io.File;
import java.io.IOException;

public class Test06 {

	public static void main(String[] args) {
		//폴더 삭제
		File dir = new File("./file/f1/f2/f3/f4/f5/");
		
		System.out.println(dir.exists());
		
		//폴더 생성
		System.out.println(dir.mkdirs());

		File f1 = new File(dir, "text.txt");
		
		try {
			System.out.println(f1.getAbsolutePath());
			System.out.println(f1.createNewFile());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		File f = new File("./file","test.txt");
		
		try {
			f.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//폴더 삭제시 내부에 파일이 있으면 삭제 불가
		System.out.println(dir.delete());
	}
	
}
