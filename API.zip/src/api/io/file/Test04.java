package api.io.file;

import java.io.File;

public class Test04 {
	// FileManager.java 클래스에
	//특정 폴더 내부의 모든 내용을 출력하는 기능 구현.
	//한후 출력
	
	public static void main(String[] args) {
		
		File f = new File(".");

		FileManager.printFolder2(f);
		
//		if(!f.isDirectory()) {
//			System.out.println(String.format("%-20s%10s%20dbyte", f.getName(),"[파일]",f.length()));
//		}else {
//			File[] files = f.listFiles();
//			for(File file : files) {
//				String res = null;
//				
//				if(file.isFile()) {
//					res = String.format("%-20s%10s%20dbyte", file.getName(),"[파일]",file.length());
//				}else if(f.isDirectory()) {
//					res = String.format("%-20s%10s", "[" + file.getName() + "]","[폴더]");
//				}
//				
//				System.out.println(res);
//			}
//		}
		
	}
	 
}
