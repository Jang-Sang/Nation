package api.io.file;

import java.io.File;

public class Test07 {

	public static void main(String[] args) {
		
		
		File dir = new File("file");
		
		FileManager.remove(dir);
		
	}
	
}
