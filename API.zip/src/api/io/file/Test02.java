package api.io.file;

import java.io.File;

public class Test02 {

	public static void main(String[] args) {
		

		File f = new File("G:\\Dropbox\\디지털데이터 융합 자바기반 풀스택개발자A 2\\JAVA\\workspace\\API");
//		File f = new File(".","sample.txt");
		
		String res = null;
		
		if(f.isFile()) {
			res = String.format("%-20s%10s%20dbyte", f.getName(),"[파일]",f.length());
		}else if(f.isDirectory()) {
			res = String.format("%-20s%10s", "[" + f.getName() + "]","[폴더]");
		}
		
		System.out.println(res);
		
	}
	
}
