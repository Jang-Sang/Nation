package api.io.file;

import java.io.File;

public class Test03 {

	public static void main(String[] args) {
		
		File f = new File(".");

		System.out.println(f.exists());
		System.out.println(f.isDirectory());
		
		String[] names = f.list(); // 파일명
		System.out.println(names.length);
		System.out.println(names[3]);
		
		File[] files = f.listFiles(); // 파일 객체
		System.out.println(files.length);
		System.out.println(files[0].length());
	}

}
