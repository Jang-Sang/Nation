package api.io.object;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class Test04 {

	public static void main(String[] args) {
		
		try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream("고삼아이스티.txt"))) {
			
			User u = (User)ois.readObject();
			
			System.out.println(u);
			
			
		}catch(IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}
	
}
