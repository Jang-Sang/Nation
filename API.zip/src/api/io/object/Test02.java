package api.io.object;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Arrays;

public class Test02 {

	public static void main(String[] args) {
		
		ObjectInputStream ois = null;
		
		//객체 입출력....
		try {
			ois = new ObjectInputStream(new FileInputStream("arrays.txt"));
			//ObjectInputStream객체 생성을 하면 4byte를 먼저 읽어서 확인을 한다..
			
			System.out.println(ois.available());// 확인 불가...
			
			Object o = ois.readObject();
			System.out.println(o.getClass());
			System.out.println(o instanceof boolean[]);
			int[] a = (int[])o;
			System.out.println(a.length);
			System.out.println(Arrays.toString(a)); // 배열 출력
			
			boolean[] b = (boolean[])ois.readObject();
			System.out.println(Arrays.toString(b));
			
			String s = (String)ois.readObject();
			
			System.out.println(s + "...." + s.matches("[A-Z]{3}"));
			
			ois.readObject();
			// available를 통해서 남아있는 데이터를 알수 없음으로..
			// 객체 수를 알고 있어야 읽어오기가 편하다...
			
		}catch(ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}finally {
			try {
				if(ois != null) {
					ois.close();
				}
			}catch(IOException e) {
				e.printStackTrace();
			}
		}
		
	}
	
}
