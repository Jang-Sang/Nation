package api.io.object;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Test01 {

	public static void main(String[] args) {
		
		int[] data = new int[] {4,1,9,15,11,6,2};
		boolean[] flag = new boolean[] {true,true,false};
		String day = "WED";
		
		ObjectOutputStream oos = null;
		
		//객체 입출력....
		try {
			oos = new ObjectOutputStream(new FileOutputStream("arrays.txt"));
			//ObjectOutputStream을 열게되면 기본 4byte 출력이 일단 일어난다...
			
			System.out.println("성공!");
			
			oos.writeObject(data);
			oos.writeObject(flag);
			oos.writeObject(day);
			
			
		}catch(IOException e) {
			e.printStackTrace();
		}finally {
			try {
				if(oos != null) {
					oos.close();
				}
			}catch(IOException e) {
				e.printStackTrace();
			}
		}
		
	}
	
}
