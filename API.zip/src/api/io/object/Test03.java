package api.io.object;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

class Item implements Serializable{
	/**
	 * 
	 */
	//직렬화 할때 그 값을 체크하는 용도의 아이디값..
	private static final long serialVersionUID = 1L;
	String name;
	public Item(String name) {
		this.name = name;
	}
}

class User implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	String nick;
	int exp = 0;
	int money = 500;
	List<Item> i;
	
	public User(String nick) {
		this.nick = nick;
		i = new ArrayList<Item>();
	}
	
	@Override
	public String toString() {
		return nick + "[" + exp + "xp, " + money + "]";
	}
}

public class Test03 {

	public static void main(String[] args) {
		
		User u = new User("고삼아이스티");
		
		System.out.println(u);
		
		//close() 작업이 가능한 Closeable 객체에 한해서
		//자동으로 close()까지 가능하도록 만든 문법....JAVA SE 7버전에 나온 문법
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(u.nick + ".txt"));){
			oos.writeObject(u);
			//java.io.NotSerializableException
			//모든 객체가 Object I/O가 가능한것은 아니다...
			//byte(숫자)화가 가능한 객체들에 한해서만 가능하다....(직렬화)
			// Serializable을 상속받아서 사용하면 된다...
			
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
}





















