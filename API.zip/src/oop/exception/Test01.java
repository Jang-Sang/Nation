package oop.exception;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Test01 {

	public void sleep() throws InterruptedException{
		Thread.sleep(1000);
	}
	
	public void sleep3s() {
		try {
			sleep();
			sleep();
			sleep();
		}catch(InterruptedException e) {
			
		}
	}
	
	public static void main(String[] args){

		new Test01().sleep3s();
		
		//Thread.sleep(1000);
		
		//예외 처리
		// - 예외를 처리하는 것...
		
		//종류
		//1. throws - JVM에게 예외 처리를 맡기는것...
		//2. try ~ catch - 우리가 직접 예외 처리를 하는것
		// - try		예외 감시 영역		필수
		// - catch		예외 처리 영역		필수
		// - finally	필수 코드 영역		선택
		
		//   - throw - 강제 예외 발생
		
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			int a = 0; int b = 0;
			try {
				System.out.print("정수 입력 : ");
				a = sc.nextInt();
				
				System.out.print("정수 입력 : ");
				b = sc.nextInt();
			}catch(InputMismatchException e) {
				sc.nextLine();
				System.out.println("정수만 입력하셔야 합니다.");
			}
			
			
			try {
				System.out.println(a + " + " + b + " = " + (a + b));
				System.out.println(a + " - " + b + " = " + (a - b));
				System.out.println(a + " × " + b + " = " + (a * b));
				System.out.println(a + " ÷ " + b + " = " + (a / b));
				System.out.println(a + " % " + b + " = " + (a % b));
			}catch(ArithmeticException e) {
				System.out.println("0으로 나눌수 없습니다.");
			}
		}
		
	}
	
}















