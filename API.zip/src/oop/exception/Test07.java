package oop.exception;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Test07 {

	public static void main(String[] args){
		
		// throw - 강제 예외 발생
		
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			try {
				System.out.print("정수 입력 : ");
				int a = sc.nextInt();
				
				if(a <= 0) {
					throw new Exception("양수만 입력할수 있습니다.");
				}
				
				System.out.print("정수 입력 : ");
				int b = sc.nextInt();
				
				if(b == 0) {
					throw new Exception("0은 입력할수 없습니다.");
//					System.out.println("0은 입력할수 없습니다.");
//					continue;
				}
				System.out.println(a + " + " + b + " = " + (a + b));
				System.out.println(a + " - " + b + " = " + (a - b));
				System.out.println(a + " × " + b + " = " + (a * b));
				System.out.println(a + " ÷ " + b + " = " + (a / b));
				System.out.println(a + " % " + b + " = " + (a % b));
				
			}catch(InputMismatchException | ArithmeticException e) {
				sc.nextLine();
				System.err.println("정수만 입력하십시오!");
			}catch(Exception e) {			
				e.printStackTrace();
			}

		}
		
	}
	
}















