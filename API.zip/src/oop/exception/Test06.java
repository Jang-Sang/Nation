package oop.exception;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Test06 {

	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			try {
				System.out.print("정수 입력 : ");
				int a = sc.nextInt();
				
				System.out.print("정수 입력 : ");
				int b = sc.nextInt();
				
				System.out.println(a + " + " + b + " = " + (a + b));
				System.out.println(a + " - " + b + " = " + (a - b));
				System.out.println(a + " × " + b + " = " + (a * b));
				System.out.println(a + " ÷ " + b + " = " + (a / b));
				System.out.println(a + " % " + b + " = " + (a % b));
				
			}catch(InputMismatchException | ArithmeticException e) {
				sc.nextLine();
				System.err.println("정수만 입력하십시오!");
			}catch(Exception e) {			
				e.printStackTrace();
			}

		}
		
	}
	
}















