package oop.exception;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Test04 {

	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			try {
				System.out.print("정수 입력 : ");
				int a = sc.nextInt();
				
				System.out.print("정수 입력 : ");
				int b = sc.nextInt();
				
				System.out.println(a + " + " + b + " = " + (a + b));
				System.out.println(a + " - " + b + " = " + (a - b));
				System.out.println(a + " × " + b + " = " + (a * b));
				System.out.println(a + " ÷ " + b + " = " + (a / b));
				System.out.println(a + " % " + b + " = " + (a % b));
				
			}catch(Exception e) {
				sc.nextLine();
				//System.err.println("에러");
				//System.out.println(e.getClass());
				//System.out.println(e);
				//System.out.println(e.getMessage());
				
				//개발용 콘솔 로그
				e.printStackTrace();
			}
			
			

		}
		
	}
	
}















