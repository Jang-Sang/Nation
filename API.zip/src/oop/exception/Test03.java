package oop.exception;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Test03 {

	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			try {
				System.out.print("정수 입력 : ");
				int a = sc.nextInt();
				
				System.out.print("정수 입력 : ");
				int b = sc.nextInt();
				
				System.out.println(a + " + " + b + " = " + (a + b));
				System.out.println(a + " - " + b + " = " + (a - b));
				System.out.println(a + " × " + b + " = " + (a * b));
				System.out.println(a + " ÷ " + b + " = " + (a / b));
				System.out.println(a + " % " + b + " = " + (a % b));
				
			}catch(InputMismatchException e) {
				sc.nextLine();
				System.out.println("정수만 입력하셔야 합니다.");
			}catch(ArithmeticException e) {
				System.out.println("0으로 나눌수 없습니다.");
			}
			
			

		}
		
	}
	
}















