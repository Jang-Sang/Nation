package oop.exception;

import java.util.Scanner;

public class Test10 {

	public static void main(String[] args) {

//		예외 처리를 이용하여 아래의 내용을 구현하세요
//		
//		사용자에게 닉네임을 입력받도록 하겠습니다
//		
//		아래의 2가지 조건에 어긋날 경우 오류 출력
//		
//		[1] 3~10글자를 벗어나는 경우 ... length()
//			→ 3~10글자 이내로 작성하세요
//		[2] 운영자라는 단어가 포함된 경우 ... indexOf()
//			→ 운영자라는 단어는 포함시킬 수 없습니다
		
		Scanner sc = new Scanner(System.in);
		String nick = null;
		try {
			System.out.print("닉네임 입력 : ");
			nick = sc.next();
			
			if(nick.length() < 4 || nick.length() > 10 || nick.indexOf("운영자") != -1) {
				throw new MyException(nick);
			}
			
		}catch(MyException e) {
			e.myCatch();
		}finally {
			sc.close();
		}


	}

}














