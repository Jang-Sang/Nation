package oop.exception;

public class MyException extends Exception{

	private String nick;
	private int errno;
	
	
	public MyException(String nick) {
		this.nick = nick;
	}
	
	public MyException(int errno) {
		this.errno = errno;
	}
	
	public MyException(String message,int errno) {
		super(message);
		this.errno = errno;
	}
	
	public void errorPrint() {
		System.err.println("errno : " + errno + ".\n" + super.getMessage());
	}
	
	public void errorPrint2() {
		if(errno == 1) {
			System.err.println("양수만 입력할수 있습니다.");
		}else if(errno == 2) {
			System.err.println("0은 입력할수 없습니다.");
		}
	}
	
	public void myCatch() {
		if(nick.length() < 4 || nick.length() > 10) {
			System.out.println("3~10글자 이내로 작성하세요");
		}
		if(nick.indexOf("운영자") != -1) {
			System.out.println("운영자라는 단어는 포함시킬 수 없습니다");
		}
	}
}















